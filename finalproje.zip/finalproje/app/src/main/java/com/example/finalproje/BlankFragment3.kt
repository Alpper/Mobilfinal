package com.example.finalproje

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.material.snackbar.Snackbar


class BlankFragment3 : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var sf =inflater.inflate(R.layout.fragment_blank3, container, false)
        var mesaj = sf.findViewById<EditText>(R.id.snackisim)
        var action = sf.findViewById<EditText>(R.id.action)
        var spinner = sf.findViewById<Spinner>(R.id.spinner)
        var sure = arrayOf("Süre Seçiniz","2 sn","2.5 sn","3 sn","3.5 sn","4 sn")

        var adapter = ArrayAdapter(sf.context,android.R.layout.simple_dropdown_item_1line,sure)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                if(p2 == 0 ){

                }
                else if(p2==1 ){
                    Snackbar.make(sf,mesaj.text,2000)
                        .setAction(action.text){
                            Toast.makeText(sf.context,action.text,Toast.LENGTH_SHORT).show()
                        }.show()
                }
                else if(p2==2 ){
                    Snackbar.make(sf,mesaj.text,2500)
                        .setAction(action.text){
                            Toast.makeText(sf.context,action.text,Toast.LENGTH_SHORT).show()
                        }.show()
                }
                else if(p2==3 ){
                    Snackbar.make(sf,mesaj.text,3000)
                        .setAction(action.text){
                            Toast.makeText(sf.context,action.text,Toast.LENGTH_SHORT).show()
                        }.show()
                }
                else if(p2==4 ){
                    Snackbar.make(sf,mesaj.text,3500)
                        .setAction(action.text){
                            Toast.makeText(sf.context,action.text,Toast.LENGTH_SHORT).show()
                        }.show()
                }
                else if(p2==5 ){
                    Snackbar.make(sf,mesaj.text,4000)
                        .setAction(action.text){
                            Toast.makeText(sf.context,action.text,Toast.LENGTH_SHORT).show()
                        }.show()
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

        }
        return sf
    }

}