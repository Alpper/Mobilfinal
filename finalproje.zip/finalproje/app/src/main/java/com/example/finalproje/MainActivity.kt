package com.example.finalproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.View
import android.widget.ProgressBar
import android.widget.SeekBar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var sb = findViewById<SeekBar>(R.id.seekBar)
        var pb = findViewById<ProgressBar>(R.id.progressBar)

        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p1 == 100) {
                    pb.visibility = View.VISIBLE
                    object : CountDownTimer(3000, 300) {
                        override fun onTick(p0: Long) {
                            sb.progress = sb.progress - 10
                        }

                        override fun onFinish() {
                        }
                    }.start()
                    Handler().postDelayed({
                        var gecis = Intent(applicationContext, MainActivity2::class.java)
                        startActivity(gecis)
                        finish()
                    }, 1000)
                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                if (sb.progress != 100) {
                    p0?.setProgress(0)
                }
            }
        })
    }
}