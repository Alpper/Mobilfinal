package com.example.finalproje

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.Toast

val dosya = "com.example.finalproje"
var anahtarisim = "isim"
var anahtarsifre = "sifre"
var unutma = "unutma"

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var isim = findViewById<EditText>(R.id.isim)
        var sifre = findViewById<EditText>(R.id.sifre)
        var switch = findViewById<Switch>(R.id.switch1)
        var pb = findViewById<ProgressBar>(R.id.progressBar2)

        var preferences = getSharedPreferences(dosya, Context.MODE_PRIVATE)
        var editor = preferences.edit()

        Toast.makeText(
            applicationContext, "Kaydedildi \n" + "isim : ${
                preferences.getString(
                    anahtarisim, "Deger Yok"
                )
            }\n" + "sifre : ${preferences.getString(anahtarsifre, "Değer Yok")}\n" +
                    "unutma : ${preferences.getString(unutma, "false")}", Toast.LENGTH_SHORT
        ).show()

        if (preferences.getString(anahtarisim, "") == "Alper Buyukkaradol") {
            isim.setText("Alper Buyukkaradol")
        }
        if (preferences.getString(anahtarsifre, "") == "02200201049") {
            sifre.setText("02200201014")
        }
        if (preferences.getString(anahtarisim, "") == "Alper Buyukkaradol" && preferences.getString(
                anahtarsifre,
                ""
            ) == "02200201049"
        ) {
            pb.visibility = View.VISIBLE
            Handler().postDelayed({
                var gecis = Intent(this, MainActivity3::class.java)
                startActivity(gecis)
            }, 2000)
        }

        isim.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var isimm = isim.text.toString()
                var sifrek = sifre.text.toString()
                if (isimm == "Alper Buyukkaradol" && sifrek == "02200201049") {
                    if (switch.isChecked() == true) {
                        editor.putString(anahtarisim, isimm.toString())
                        editor.putString(anahtarsifre, sifrek.toString())
                        editor.apply()
                        pb.visibility = View.VISIBLE
                        var gecis = Intent(this@MainActivity2, MainActivity3::class.java)
                        startActivity(gecis)
                    } else {
                        editor.remove(anahtarisim)
                        editor.remove(anahtarsifre)
                        editor.apply()
                        pb.visibility = View.VISIBLE
                        var gecis = Intent(this@MainActivity2, MainActivity3::class.java)
                        startActivity(gecis)
                    }
                }
            }
        })
        sifre.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                var isimm = isim.text.toString()
                var sifrek = sifre.text.toString()
                if (isimm == "Alper Buyukkaradol" && sifrek == "02200201049") {
                    if (switch.isChecked() == true) {
                        editor.putString(anahtarisim, isimm.toString())
                        editor.putString(anahtarsifre, sifrek.toString())
                        editor.apply()
                        pb.visibility = View.VISIBLE
                        var gecis = Intent(this@MainActivity2, MainActivity3::class.java)
                        startActivity(gecis)
                    } else {
                        editor.remove(anahtarisim)
                        editor.remove(anahtarsifre)
                        editor.apply()
                        pb.visibility = View.VISIBLE
                        var gecis = Intent(this@MainActivity2, MainActivity3::class.java)
                        startActivity(gecis)
                    }
                }
            }
        })
    }
}