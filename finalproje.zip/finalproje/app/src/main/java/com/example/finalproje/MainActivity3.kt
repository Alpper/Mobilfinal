package com.example.finalproje

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        var menu = findViewById<Button>(R.id.button)


        menu.setOnClickListener {
            val acilirmenu = PopupMenu(this, menu)
            acilirmenu.menuInflater.inflate(R.menu.menu, acilirmenu.menu)
            acilirmenu.setOnMenuItemClickListener { i -> when (i.itemId) {
                R.id.rgb -> {
                    fragmentcagir(BlankFragment2())
                    true
                }
                R.id.snack -> {
                    fragmentcagir(BlankFragment3())
                    true
                }
                R.id.cikis -> {
                    var preferences =getSharedPreferences(dosya, Context.MODE_PRIVATE)
                    var editor = preferences.edit()
                    val cik =layoutInflater.inflate(R.layout.cikisalert,null)
                    val ad = AlertDialog.Builder(this@MainActivity3)
                    ad.setView(cik)
                    var isim = cik.findViewById<EditText>(R.id.isimcikis)
                    var sifre = cik.findViewById<EditText>(R.id.sifrecikis)
                    var pb = cik.findViewById<ProgressBar>(R.id.progressBar3)

                    isim.addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

                        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int){
                            var isimm = isim.text.toString()
                            var no = sifre.text.toString()
                            if(isimm=="Alper Buyukkaradol" && no =="02200201049"){
                                editor.remove(anahtarisim)
                                editor.remove(anahtarsifre)
                                editor.remove(unutma)
                                    .commit()
                                pb.visibility = View.VISIBLE
                                var gecis = Intent(this@MainActivity3,MainActivity2::class.java)
                                startActivity(gecis)
                            }

                        }

                        override fun afterTextChanged(p0: Editable?) {}

                    })
                    sifre.addTextChangedListener(object : TextWatcher {
                        override fun afterTextChanged(p0: Editable?) {
                        }
                        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                        }
                        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                            var isimm = isim.text.toString()
                            var no = sifre.text.toString()
                            if(isimm=="Alper Buyukkaradol" && no =="02200201049"){
                                editor.remove(anahtarisim)
                                editor.remove(anahtarsifre)
                                editor.remove(unutma)
                                    .commit()
                                pb.visibility = View.VISIBLE
                                var gecis = Intent(this@MainActivity3,MainActivity2::class.java)
                                startActivity(gecis)
                            }
                        }
                    })
                    ad.create().show()
                    true


                }
                else -> false
            }

            }
            acilirmenu.show()

        }

    }
    fun fragmentcagir (bolum : Fragment){
        var gecis1 = supportFragmentManager.beginTransaction()
        gecis1.replace(R.id.fragmentContainerView,bolum)
        gecis1.commit()
    }

}